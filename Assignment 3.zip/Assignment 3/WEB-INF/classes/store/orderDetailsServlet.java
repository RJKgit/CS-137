package store;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class orderDetailsServlet
 */
@WebServlet(description = "Store", urlPatterns = { "/orderDetailsServlet" })
//@WebServlet("/orderDetailsServlet")
public class orderDetailsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public orderDetailsServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	response.setContentType("text/html");
		
        //JDBC Connection
    	String sqlLogin = "inf124grp06";
   		String sqlPass = "#e4ubreF";
   		String sqlURL = "jdbc:mysql://sylvester-mccoy-v3:3306/inf124grp06?useSSL=false";

   		/*String sqlLogin = "testuser";
   		String sqlPass = "testpass";
   		String sqlURL = "jdbc:mysql://localhost:3306/inf124grp06?useSSL=false";
   		*/
   		
        Connection connection;
        Statement stmt;
        
        String confNum = (String) request.getSession().getAttribute("num");
     
        try{
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            connection = DriverManager.getConnection(sqlURL, sqlLogin, sqlPass);
            stmt = connection.createStatement();
            
            String query = "SELECT * FROM orders WHERE confirmation_number='" + confNum + "'";
            ResultSet rs = stmt.executeQuery(query);

            List<Order> confirmationList = new ArrayList<Order>();
            while(rs.next()){
            	Order ord = new Order(rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4),
            			rs.getString(5), rs.getString(6), rs.getString(7));
            	
            	Statement stmt2 = connection.createStatement();
            	ResultSet temp = stmt2.executeQuery("SELECT first_name, last_name, email, phone_number, "
            			+ "street_address, city, state, zipcode "
            			+ "FROM customers WHERE id='" + ord.customer_id + "'");

            	while(temp.next()){
            		ord.setCustomerInfo(temp.getString(1), temp.getString(2), temp.getString(3), temp.getString(4), 
            				temp.getString(5), temp.getString(6), temp.getString(7), temp.getString(8));
            	}
            	confirmationList.add(ord);
            }

            request.getSession().setAttribute("orderList", confirmationList);
            request.getRequestDispatcher("/orderForm.jsp").forward(request, response);

            connection.close();

        }catch(Exception e){
        	request.getSession().setAttribute("confirmation", "Error Occurred! " + e.getMessage());
            request.getRequestDispatcher("/checkout.jsp").forward(request, response);
        }
	}

}
