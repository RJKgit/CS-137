package store;

public class Item {
    public String ID;
    public String name;
    public String description;
    public String material;
    public String price;
    public String image1_URL;
    public String image2_URL;
    public String image3_URL;
    public int quantity;
    
    public Item(String ID, String N, String D, String M, String P, String URL1, 
    		String URL2, String URL3){
        this.ID = ID;
        this.name = N;
        this.description = D;
        this.material = M;
        this.price = P;
        this.image1_URL = URL1;
        this.image2_URL = URL2;
        this.image3_URL = URL3;
        this.quantity = 1;
    }

}
