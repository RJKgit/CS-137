package store;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 * Servlet implementation class orderServlet
 */
@WebServlet(description = "Store", urlPatterns = { "/orderServlet" })
//@WebServlet("/orderServlet")
public class orderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public orderServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    	response.setContentType("text/html");
		
      //JDBC Connection
    	String sqlLogin = "inf124grp06";
   		String sqlPass = "#e4ubreF";
   		String sqlURL = "jdbc:mysql://sylvester-mccoy-v3:3306/inf124grp06?useSSL=false";
   		
   	/*	String sqlLogin = "testuser";
   		String sqlPass = "testpass";
   		String sqlURL = "jdbc:mysql://localhost:3306/inf124grp06?useSSL=false";
   		*/
   		
        Connection connection;
        Statement stmt;
        
        List<Item> cart = (List<Item>) request.getSession().getAttribute("cart");

        String fn = request.getParameter("first");
        String ln = request.getParameter("last");
        String email = request.getParameter("email");
        String phone = request.getParameter("phone");
        String creditcard = request.getParameter("card");
        String street = request.getParameter("street");
        String city = request.getParameter("city");
        String state = request.getParameter("state");
        String zip = request.getParameter("zip");
        String ship = request.getParameter("ship");
        String total = request.getParameter("total");
        int success = -1;
        
        //confirmation/order number
        Random rand = new Random();
    	String confNum = Integer.toString(rand.nextInt(999999999) + 111111111);
        PrintWriter out = response.getWriter();

        try{
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            connection = DriverManager.getConnection(sqlURL, sqlLogin, sqlPass);
            stmt = connection.createStatement();
            
            String check = "SELECT * FROM orders where confirmation_number='" + confNum + "'";
            Statement stmt2 = connection.createStatement();
            ResultSet rsc = stmt2.executeQuery(check);
            
            while(rsc.first()){
            	confNum = Integer.toString(rand.nextInt(999999999) + 11111);
                check = "SELECT * FROM orders where confirmation_number='" + confNum + "'";
                rsc = stmt.executeQuery(check);
            }
            
            String update = "INSERT INTO customers (id, first_name, last_name, email, phone_number, street_address, city, state, zipcode, creditcard_number)" 
            		+ "VALUES (NULL, '" + fn + "', '" + ln + "', '" + email + "', '" + phone + "', '" + street
            		+ "', '" + city + "', '" + state + "', '" + zip + "', '" + creditcard + "')";
            
            success = stmt.executeUpdate(update);
            
            if(success != -1){
            	ResultSet rs = stmt.executeQuery("SELECT id FROM customers "
            			+ "WHERE id = (SELECT MAX(id) FROM customers)");
            	String customer_id = "";            	
            	while(rs.next()){
            		customer_id = rs.getString(1);
            	}
            	
            	success = stmt.executeUpdate("SET foreign_key_checks = 0");

            	for(Item i : cart){
                     String update2 = "INSERT INTO orders (orderNo, quantity, shipping_method, total, items_id, customer_id, confirmation_number)"
                    		+ "VALUES (null, '" + i.quantity + "', '" + ship + "', '" + total + "', '" + i.ID + "', '" 
                    		+ customer_id + "', '" + confNum + "')";
                    
                    success = stmt.executeUpdate(update2);
                     
                    if(success == -1)
                    	break;
            	}

            	stmt.executeUpdate("SET foreign_key_checks = 1");

                if(success != -1){
                	request.getSession().setAttribute("num", confNum);
                    request.getRequestDispatcher("orderDetailsServlet").forward(request, response);
                }
                else{
                	request.getSession().setAttribute("confirmation", "Request cannot be processed at this time");
                    request.getRequestDispatcher("orderDetailsServlet").forward(request, response);
                }
            }
            else{
            	request.getSession().setAttribute("confirmation", "Request cannot be processed at this time");
                request.getRequestDispatcher("orderDetailsServlet").forward(request, response);
            }
            
			connection.close();
						
        }catch(Exception e){
        	request.getSession().setAttribute("confirmation", "Error Occurred! " + e.getMessage());
            request.getRequestDispatcher("orderDetailsServlet").forward(request, response);
        }
    	
	}

}
