Home Page URL: http://andromeda-6.ics.uci.edu:58181/prj3/home.jsp
Other Important URLs:
	http://andromeda-6.ics.uci.edu:58181/prj3/products.jsp
		Displays the products and the recently viewed products
Part 1:
	(1) Assignment3/WebContent/products.jsp
		Retrieves two session objects that are lists. One that has the recently viewed products and the other that has all the products we sell. It then displays the recently viewed products and then all the products on the page.
	(2) Assignment3/Java Resources/src/(default package)/productListServlet.java
		Connects to the database and the runs a query to get the product information. It then stores it into a List of type Items(described in file 4). The list is then stored into a session object used in products.jsp(file 1).	
	(3) Assignment3/Java Resources/src/(default package)/recentServlet.java
		Creates a Session Object that stores all the recently viewed products and appends to it as new ones are viewed. Is then used to be displayed in products.jsp(file 1).
	(4) Assignment3/Java Resources/src/foogleObject/Item.java
		Creates a class called Item that stores information about the product.
Part 2:
	(1) Assignment3/Java Resources/src/(default package)/productDetailsServlet.java
		Recieves a parameter of 'id' for product id number and then connects to a database to retrieve information about that product. Then adds the product to recent session object if it is not already in there. Also, sends the product information to productDetails.jsp(File 2).
	(2) Assignment3/WebContent/productDetails.jsp
		Retrieves the product information sent from productDetailsServlet.java(File 1) and then displays the product details onto the page. (Continued on Part 3) Calls checkoutServlet when a product is added to the Cart. (Part 4 File 3)
Part 3:
	(1) Assignment3/WebContent/productDetails.jsp
		Creates a context object with key of the item id and saves a vector of ip addresses to it. If the Ip address is already there then it ignores it. It then takes the size of the vector and displays it as the number of views near the top of the page.
Part 4:
	(1) Assignment3/WebContent/checkout.jsp
		Retrieves a Session Object that has all the Products stored into the Shopping Cart and displays the products. Displays a form for the user to enter their information which is validated by checkout.js(File 2). Calculates and displays the total price at the bottom of the page,
	(2) Assignment3/WebContent/checkout.js
		Validates the checkout form and has a function that adds the shipping cost to the total.
	(3) Assignment3/Java Resources/src/(default package)/checkoutServlet.java
		Is called by productDetails.jsp(Part 2 File 2) with the parameter of product id. Connects to the database and retrieves information about the product and stores it into a session object for the shopping cart.
	(4) Assignment3/Java Resources/src/(default package)/orderServlet.java
		Connects to a database to insert the order information into a table. Gives Error messages if cannot insert the information.
	(5) Assignment3/Java Resources/src/foogleObject/Order.java
		Creates a class called Order that stores the customer's information and the order information.
Part 5:
	(1) Assignment3/WebContent/orderForm.jsp
		Retrieves the session object created by orderDetailsServlet.java(File 2) and displays an order confirmation page.
	(2) Assignment3/Java Resources/src/(default package)/orderDetailsServlet.java
		Connects to the database to retrieve the order information and customer information and then stores it into a Order object(File 3). The Order object is then stored into a session object.
	(3) Assignment3/Java Resources/src/foogleObject/Order.java
		Creates a class called Order that stores the customer's information and the order information.
Static Files:
	(1)Assignment3/WebContent/foogleHeader.html
		Static menu that is displayed at the top of all web display files
	(2)Assignment3/WebContent/home.jsp
		Starting homepage that allows you to access all the other important pages.
	(3)Assignment3/WebContent/about.jsp
		displays information about who we are and information about our company

Contributors(Group 6):
	Amit Dhingra	90708655
	Mukesh Kastala	40646351 
	Rajiv Koya		21027060 
	Victor Masivi	72803855


