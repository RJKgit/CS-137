

import java.io.IOException;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import foogleObject.Item;
import java.util.ArrayList;
import java.util.List;
import java.io.*;

/**
 * Servlet implementation class productListServlet
 */
@WebServlet("/productListServlet")
public class productListServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public productListServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		response.setContentType("text/html");
		
        //JDBC Connection
        String sqlLogin = "inf124grp06";
        String sqlPass = "#e4ubreF";
        String sqlURL = "jdbc:mysql://sylvester-mccoy-v3:3306/info124grp06?useSSL=false";
        Connection connection;
        Statement stmt;
        

        try{
            Class.forName("com.mysql.jdbc.Driver").newInstance();
            connection = DriverManager.getConnection(sqlURL, sqlLogin, sqlPass);
            stmt = connection.createStatement();
               
            String query = "SELECT * FROM items";
            ResultSet rs = stmt.executeQuery(query);

            List<Item> ilist = new ArrayList<Item>();
            while(rs.next()){
                Item l = new Item(rs.getString(1), rs.getString(2), rs.getString(3), 
                        rs.getString(4), rs.getString(5), rs.getString(6), rs.getString(7),
                        rs.getString(8));
                
                ilist.add(l); //add the new Item object	
            }
        	
            connection.close();
            request.getSession().setAttribute("items", ilist);
            response.sendRedirect(request.getContextPath() + "/products.jsp"); 
            //request.getRequestDispatcher("/products.jsp").forward(request, response);
            
        }catch(Exception e){
        	PrintWriter out = response.getWriter();
        	out.println("Error" + e.getMessage());
        }
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
