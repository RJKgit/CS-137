package foogleObject;

public class Order {
	
	public String orderNo;
	public String quantity;
	public String shipping;
	public String total;
	public String item_id;
	public String customer_id;
	public String confirmation_num;
	
	public String first;
	public String last;
	public String email;
	public String phone;
	public String street;
	public String city;
	public String state;
	public String zip;
	
	public Order(String no, String qt, String ship, String tot, String item, String cus, String conf){
		this.orderNo = no;
		this.quantity = qt;
		this.shipping = ship;
		this.total = tot;
		this.item_id = item;
		this.customer_id = cus;
		this.confirmation_num = conf;
	}
	public void setCustomerInfo(String f, String l, String e, String p, String sr, String c, String st, String zip){
		this.first = f;
		this.last = l;
		this.email = e;
		this.phone = p;
		this.street = sr;
		this.city = c;
		this.state = st;
		this.zip = zip;
	}
}
