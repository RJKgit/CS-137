Home Page URL: 

Static Files:
	Assignment3/WebContent/foogleHeader.html
		Static menu that is displayed at the top of all web display files

	Assignment3/WebContent/home.jsp
		Starting homepage that allows you to access all the other important pages.

	Assignment3/WebContent/about.jsp
		displays information about who we are and information about our company

Part 1:
	Assignment3/WebContent/products.jsp
		Retrieves two session objects that are lists. One that has the recently viewed products and the other that has all the products we sell. It then displays the recently viewed products and then all the products on the page.

	Assignment3/Java Resources/src/(default package)/productListServlet.java
		
	Assignment3/Java Resources/src/(default package)/recentServlet.java
	Assignment3/Java Resources/src/foogleObject/Item.java
		Creates a class called Item that stores information about the product.
Part 2:
	Assignment3/Java Resources/src/(default package)/productDetailsServlet.java
	Assignment3/WebContent/productDetails.jsp
Part 3:
	Assignment3/WebContent/productDetails.jsp
		Creates a context object with key of the item id and saves a vector of ip addresses to it. If the Ip address is already there then it ignores it. It then takes the size of the vector and displays it as the number of views near the top of the page.
Part 4:
	Assignment3/WebContent/checkout.jsp
	Assignment3/WebContent/checkout.js
		Validates the checkout form and has a function that adds the shipping cost to the total
	Assignment3/Java Resources/src/(default package)/checkoutServlet.java
	Assignment3/Java Resources/src/(default package)/orderServlet.java
	Assignment3/Java Resources/src/foogleObject/Order.java
		Creates a class called Order that stores the customer's information and the order information.
Part 5:
	Assignment3/WebContent/orderForm.jsp
	Assignment3/Java Resources/src/(default package)/orderDetailsServlet.java
	Assignment3/Java Resources/src/foogleObject/Order.java
		Creates a class called Order that stores the customer's information and the order information.







