CS 137/INF 124 Assignment 1
Contributors:			Student ID:
		Amit Dhingra	90708655
		Mukesh Kastala	40646351 
		Rajiv Koya	21027060 
		Victor Masivi	72803855


URL: http://andromeda-6.ics.uci.edu:13855/home.htm

We created a website that opens up with the main page FOOGLE. From the main page you can access the Products page or the About Us page through a navigation bar at the top of the page. From the Products page you can access each products information page dynamically by clicking on more info or on the image. From that product page you can click purchase which will bring you to a form to enter your information and allow you to make the purchase. This form will make sure each field is filled in properly and provide suggestions on what to fill for city, state, and zip codes dynamically. The confirmation page is also then created dynamically when you submit. The users information and order information is then stored into a database and updated with each transaction.